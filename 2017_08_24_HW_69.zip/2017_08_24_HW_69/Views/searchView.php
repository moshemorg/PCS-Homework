<?php

class searchView extends render {

    public function renderPage() {

?>

<h1>Work in progress</h1>
<h2>Search View Page</h2>

<?php

    }

}

?>