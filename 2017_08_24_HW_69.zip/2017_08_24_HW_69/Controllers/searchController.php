<?php

    include 'Models/searchModel.php';
    include 'Views/searchView.php';

    $display = new searchView;
    $display->render();

?>